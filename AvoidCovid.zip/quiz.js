console.log("quiz page");

const truebutton = document.querySelector("#TrueB");
const falsebutton = document.querySelector("#FalseB");

const info = ["Incorrect!", "Correct!"]


// console.log(truebutton)

//question #4
truebutton.addEventListener("click", e => {
    console.log("related button clicked")
    infoDiv4.innerHTML = `<p>${info[1]}</p>`

})

falsebutton.addEventListener("click", e => {
  console.log("related button clicked")
  infoDiv4.innerHTML = `<p>${info[0]}</p>`

})
 
 let infoDiv4= document.querySelector("#infoDiv4")
  console.log("truebutton")
//end question #4


//question #2 section
 const torchbutton = document.querySelector("#Torch")
 const palebutton = document.querySelector("#Pale")
 

//true or false for question 2
 torchbutton.addEventListener("click", e => {
   console.log("torchbutton clicked")
   infoDiv2.innerHTML = `<p>${info[1]}</p>` 
 })
 
 palebutton.addEventListener("click", e => {
   console.log("palebutton clicked")
   infoDiv2.innerHTML = `<p>${info[0]}</p>`
 })

//question #5 section
const fatigue = document.querySelector("#Fatigue");
const vision = document.querySelector ("#Vision");
let infoDiv5= document.querySelector("#infoDiv5")
  console.log("fatigue")
  
fatigue.addEventListener("click", e => {
    console.log("fatigue button clicked")
    infoDiv5.innerHTML = `<p>${info[0]}</p>`

})

vision.addEventListener("click", e => {
    console.log("vision button clicked")
    infoDiv5.innerHTML = `<p>${info[1]}</p>`

})





// question #1 

 const relatedbutton = document.querySelector("#related")
 const livebutton = document.querySelector("#Live")
 let infoDiv1 = document.querySelector("#infoDiv1") 
    console.log("live")

// section for question 1
  relatedbutton.addEventListener("click", e => {
   console.log("relatedbutton clicked")
   infoDiv1.innerHTML = `<p>${info[0]}</p>` 
 })
 
 livebutton.addEventListener("click", e => {
   console.log("livebutton clicked")
   infoDiv1.innerHTML = `<p>${info[1]}</p>`
 })



//question 3

const sixty = document.querySelector("#sixty")
const eighty = document.querySelector("#eighty")

//section #3
sixty.addEventListener("click", e => {
  console.log("button works")
  infoDiv3.innerHTML = `<p>${info[1]}</p>`
})

eighty.addEventListener("click", e => {
  console.log("this works")
  infoDiv3.innerHTML = `<p>${info[0]}</p>`
})