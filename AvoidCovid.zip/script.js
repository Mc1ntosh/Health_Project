console.log("is this working?");

const truebutton = document.querySelector("#TrueButton");
const falsebutton = document.querySelector("#FalseButton");

// const info = ["Incorrect!", "Correct!"]


// console.log(truebutton)


// truebutton.addEventListener("click", e => {
//     console.log("related button clicked")
// })

//test.addEventListener("click", e => {
  //console.log("related button clicked")
  //infoDiv.innerHTML = `<p>${info[0]}</p>`

//})
 



